<?php
include '../../../autoload.php';
use model\Cities;
$Cities = new Cities();
if (isset($_POST['controller_type']) or isset($_GET['controller_type'])) {
    if (isset($_POST['controller_type'])) {
        $type = $_POST['controller_type'];
    }
    if (isset($_GET['controller_type'])) {
        $type = $_GET['controller_type'];
    }
    switch ($type) {
        case 'add':
            unset($_POST['controller_type']);
            $_POST = checkAll($_POST);
            echo showResult($Cities->AddCities($_POST), 'شهر', 'افزودن');
            break;
        case 'get':
            $cid = $_GET['cid'];
            echo json_encode($Cities->GetCitiesById($cid));
            break;
        case 'edit':
            unset($_POST['controller_type']);
            $_POST = checkAll($_POST);
            echo showResult($Cities->EditCities($_POST['cid'], $_POST), 'شهر', 'ویرایش');
            break;
        case "delete":
            echo showResult($Cities->DeleteCities($_POST['cid']), 'شهر', 'حذف');
            break;
    }
} else {
    echo json_encode($Cities->CitiesWithState());
}