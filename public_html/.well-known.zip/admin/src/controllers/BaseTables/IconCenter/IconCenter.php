<?php
require_once '../../../helpers/helpers.php';
require_once '../../../models/DATABASE.php';
require_once '../../../models/BaseTables/IconCenter/Icons.php';
use model\Icons;
$Icons = new Icons();
if (isset($_POST['controller_type']) or isset($_GET['controller_type'])) {
    if (isset($_POST['controller_type'])) {
        $type = $_POST['controller_type'];
    }
    if (isset($_GET['controller_type'])) {
        $type = $_GET['controller_type'];
    }
    switch ($type) {
        case 'add':
            unset($_POST['controller_type']);
            $_POST = checkAll($_POST);
            $_POST['sdate'] = time();
            if ($_FILES['pic']['name']) {
                if ($icon = upload($_FILES['pic'], "../../../images/icons/")) {
                    $_POST['pic'] = $icon;
                    echo showResult($Icons->AddIcons($_POST), 'آیکون', 'افزودن');
                } else {
                    echo showErrorMsg("عکس", "آپلود");
                }
            } else {
                echo showResult($Icons->AddIcons($_POST), 'آیکون', 'افزودن');
            }
            break;
        case 'get':
            $icon_id = $_GET['icon_id'];
            echo json_encode($Icons->GetIconsById($icon_id));
            break;
        case 'edit':
            unset($_POST['controller_type']);
            $_POST = checkAll($_POST);
            echo showResult($Icons->EditIcons($_POST['icon_id'], $_POST), 'آیکون', 'ویرایش');
            break;
        case "delete":
            unlink('../../images/Icons/' . $Icons->GetPic($_POST['icon_id']));
            echo showResult($Icons->DeleteIcons($_POST['icon_id']), 'آیکون', 'حذف');
            break;
        case "getId":
            $url = explode("/",$_POST['imgUrl']);
            $url  = str_replace('"',"",end($url));
            echo $Icons->GetId($url);
            break;
    }
} else {

    echo json_encode($Icons->GetAllIcons());
}