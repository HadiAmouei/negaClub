
<li class="dropdown">
    <a href="#" class="nav-link dropdown-toggle" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
        <?=$Admin->getName()?> <b class="caret"></b>
    </a>
    <div class="dropdown-menu user-panel dropdown-menu-right">
        <a class="dropdown-item ajax" rel="EditProfile.php">ویرایش پروفایل</a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="sign-out.php">خروج</a>
    </div>
</li>