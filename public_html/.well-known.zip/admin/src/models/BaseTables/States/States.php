<?php
namespace model;
use DATABASE\Model;

class States extends Model
{
    const table = 'tblStates';
    const key = 'state_id';
}