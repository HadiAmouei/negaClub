<?php
include "../../../helpers/helpers.php";
$IconCenter = ValidateRequestForPageLoad($_POST);
echo CheckLoadedDataFromAjaxCall($IconCenter);
?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>مدیریت آیکون ها</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-left">
                    <li class="breadcrumb-item"><a href="index.php">خانه</a></li>
                    <li class="breadcrumb-item ajax"><a href="#" rel="BaseTables/BaseTables.php">جداول پایه</a></li>
                    <li class="breadcrumb-item active">مدیریت آیکون ها</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="row">

        <div class="col-md-12">

            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">آیکون ها</h3>
                    <a rel="BaseTables/IconCenter/addIconCenter.php" class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-plus"></i> افزودن آیکون</a>
                    <a rel="BaseTables/IconCenter/IconCenter.php" class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-refresh"></i> تازه سازی</a>
                </div>
                <div class="card-body d-flex flex-wrap table-responsive">
                    <table class="table DataTable table-bordered table-striped table-hover">
                        <thead class="table-dark">
                        <tr>
                            <th>ردیف</th>
                            <th>نام</th>
                            <th>آیکون</th>
                            <th class="no-sort" width="200">عملیات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 0;
                        foreach ($IconCenter as $icon) {
                            $i++;
                            ?>
                            <tr>
                                <td><?= $i; ?></td>
                                <td><?= $icon->name ?></td>
                                <td><img style="width: 65px;height: auto" src="images/icons/<?=$icon->pic?>" alt=""></td>
                                <td>
                                    <a rel="BaseTables/IconCenter/viewIconCenter.php?icon_id=<?= $icon->icon_id; ?>"
                                       class="btn btn-info ajax" data-toggle="tooltip" title="مشاهده"><i
                                                class="fa fa-eye"></i> </a>
                                    <a rel="BaseTables/IconCenter/editIconCenter.php?icon_id=<?= $icon->icon_id; ?>"
                                       class="btn btn-info ajax" data-toggle="tooltip" title="ویرایش"><i
                                                class="fa fa-edit"></i> </a>
                                    <a rel="BaseTables/IconCenter/deleteIconCenter.php?icon_id=<?= $icon->icon_id; ?>"
                                       class="btn btn-info ajax" data-toggle="tooltip" title="حذف"><i
                                                class="fa fa-trash"></i> </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th class="no-sort">ردیف</th>
                            <th>آیکون</th>
                            <th>آیکون</th>
                            <th class="no-sort" width="200">عملیات</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    $(document).ajaxStart(function () {
        Pace.restart();
    });
    $.Ajax();
    $.table();
</script>
