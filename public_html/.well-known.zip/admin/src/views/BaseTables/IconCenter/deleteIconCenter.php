<?php
include "../../../helpers/helpers.php";
$icon = ValidateRequestForPageLoad($icon);?>

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>مدیریت آیکون ها</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-left">
                    <li class="breadcrumb-item"><a href="index.php">خانه</a></li>
                    <li class="breadcrumb-item ajax"><a href="#" rel="BaseTables/BaseTables.php">جداول پایه</a></li>
                    <li class="breadcrumb-item active">مدیریت آیکون ها</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="row">

        <div class="col-md-12">


            <div class="card card-primary card-outline">
                <div class="card-header with-border">
                    <h3 class="card-title"> حذف آیکون</h3>
                    <a rel="BaseTables/IconCenter/IconCenter.php" class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-chevron-left"></i> بازگشت</a>
                    <a rel="BaseTables/IconCenter/deleteIconCenter.php?icon_id=<?= $icon->icon_id ?>"
                       class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-refresh"></i> تازه
                        سازی</a>
                </div>

                <form id="idForm" method="post" action="">
                    <input name="controller_type" value="delete" type="hidden">
                    <input name="icon_id" value="<?= $icon->icon_id ?>" type="hidden">
                    <div class="card-body d-flex flex-wrap table-responsive">

                        <div class="form-group col-md-4">
                            <label for="name">نام آیکون </label>
                            <input disabled type="text" value="<?= $icon->name ?>" class="form-control" name="name" id="name"
                                   autocomplete="off" required>
                        </div>
                        <div class="form-group col-md-4">
                            <img src="images/icons/<?=$icon->pic?>" alt="" style="width: 100px;height: auto">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" name="submit" class="btn btn-primary pull-left"><i class="fa fa-trash"></i>
                            حذف آیکون
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<script>


    $("#idForm").submit(function (e) {
        let formData = new FormData(this);
        $.ajax({
            type: 'POST',
            url: 'controllers/BaseTables/IconCenter/IconCenter.php',
            data: formData,
            async: false,
            success: function (data) {
                $('#idForm').html(data);
            },
            cache: false,
            contentType: false,
            processData: false
        });
        e.preventDefault();
    });
    $('.tooltip').hide();
    $(document).ajaxStart(function () {
        Pace.restart();
    });
    $.Ajax();
    $('textarea').trumbowyg();
</script>
<script>

