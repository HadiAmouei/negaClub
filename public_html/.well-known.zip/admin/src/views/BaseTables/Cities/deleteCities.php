<?php
include "../../../helpers/helpers.php";
$city = ValidateRequestForPageLoad($_POST);
echo CheckLoadedDataFromAjaxCall($city);
$coordsArr = explode(")",
    str_replace("(", "", $city->polygon)
);
$firstPos = explode(",", $coordsArr[0]);
?>
<style>
    .map {
        width: 100%;
        height: 400px;
    }
</style>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>مدیریت شهر ها</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-left">
                    <li class="breadcrumb-item"><a href="index.php">خانه</a></li>
                    <li class="breadcrumb-item ajax"><a href="#" rel="BaseTables/BaseTables.php">جداول پایه</a></li>
                    <li class="breadcrumb-item active">مدیریت شهر ها</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="row">

        <div class="col-md-12">


            <div class="card card-primary card-outline">
                <div class="card-header with-border">
                    <h3 class="card-title"> حذف شهر</h3>
<a rel="BaseTables/Cities/Cities.php" class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-chevron-left"></i> بازگشت</a>
                    <a rel="BaseTables/Cities/deleteCities.php?cid=<?= $city->cid; ?>"
                       class="btn btn-outline-primary pull-left ajax"><i
                                class="fa fa-refresh"></i> تازه
                        سازی</a>
                </div>

                <form id="idForm" method="post" action="">
                    <input type="hidden" name="cid" value="<?= $city->cid; ?>">
                    <input type="hidden" name="controller_type" value="delete">
                    <div class="card-body d-flex flex-wrap table-responsive">

                        <div class="form-group col-md-6">
                            <label for="name">نام شهر </label>
                            <input type="text" class="form-control" name="name" id="name" disabled autocomplete="off" required
                                   value="<?= $city->name; ?>">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="state_id">انتخاب استان</label>
                            <select disabled class="form-control" name="state_id" id="state_id">
                                <?= select('tblStates', 'name', 'sid', $city->state_id, false); ?>
                            </select>
                        </div>

                        <div class="form-group col-md-12">
                            <label>لطفا محدوده شهر را مشخص کنید</label>
                            <div disabled="" class="map" id="map">
                            </div>
                            <div>
                                <input type="hidden" value="<?=$city->polygon?>" name="polygon" disabled id="map-coords">
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" name="submit" class="btn btn-primary pull-left"><i class="fa fa-trash"></i>
                            حذف شهر
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</section>

<script>
    $(function () {
        var mymap = L.map('map').setView([<?=$firstPos[0];?>, <?=$firstPos[1];?>], 13);
        L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoiYW1pcjc1OTYiLCJhIjoiY2pqcXFyZTU4MTR1YjN3bW02aXN3b3o2dSJ9.t13qJLhSWuq0bSOje1BBCA', {
            maxZoom: 18,
        }).addTo(mymap);
        var polygon = L.polygon([
            <?php
            foreach ($coordsArr as $coords) {
                if ($coords != "") {
                    $point = explode(',', $coords);
                    echo "[" . $point[0] . ',' . $point[1] . '],';
                }
            }
            ?>
        ]).addTo(mymap);
        var editableLayers = new L.FeatureGroup();
        mymap.addLayer(editableLayers);

        var drawPluginOptions = {
            position: 'topright',
            draw: {
                polygon: {
                    allowIntersection: true, // Restricts shapes to simple polygons
                    drawError: {
                        color: '#e1e100', // Color the shape will turn when intersects
                        message: 'این شکل قابل رسم نیست!!' // Message that will show when intersect
                    },
                    shapeOptions: {
                        color: '#97009c'
                    }
                },
                // disable toolbar item by setting it to false
                polyline: false,
                circle: false, // Turns off this drawing tool
                rectangle: false,
                marker: false,
            },
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: false
            }
        };

        // Initialise the draw control and pass it the FeatureGroup of editable layers
        var drawControl = new L.Control.Draw(drawPluginOptions);
        mymap.addControl(drawControl);

        var editableLayers = new L.FeatureGroup();
        mymap.addLayer(editableLayers);

        mymap.on('draw:created', function (e) {
            var type = e.layerType,
                layer = e.layer;
            var points = e.layer._latlngs;
            var len = points[0].length;
            var lats = "";
            for (var i = 0; i < len; i++) {
                lats += "(" + points[0][i].lat + "," + points[0][i].lng + ")";
            }
            $("#map-coords").val(lats);
            editableLayers.addLayer(layer);
        });

    });

    $("#idForm").submit(function (e) {
        let formData = new FormData(this);
        $.ajax({
            type: 'POST',
            url: 'controllers/BaseTables/Cities/Cities.php',
            data: formData,
            async: false,
            success: function (data) {
                $('#idForm').html(data);
            },
            cache: false,
            contentType: false,
            processData: false
        });
        e.preventDefault();
    });
    $('.tooltip').hide();
    $(document).ajaxStart(function () {
        Pace.restart();
    });
    $("select").select2();
    $.Ajax();
</script>

